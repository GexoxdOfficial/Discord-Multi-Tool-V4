import colorama
from colorama import Fore
import asyncio
import aiohttp
import random
import json
import os

colorama.init()

print(Fore.GREEN + '''

 ███▄ ▄███▓ █    ██  ██▓  ▄▄▄█████▓ ██▓   ▄▄▄█████▓ ▒█████   ▒█████   ██▓        ███▄    █  ██▓▄▄▄█████▓ ██▀███   ▒█████  
▓██▒▀█▀ ██▒ ██  ▓██▒▓██▒  ▓  ██▒ ▓▒▓██▒   ▓  ██▒ ▓▒▒██▒  ██▒▒██▒  ██▒▓██▒        ██ ▀█   █ ▓██▒▓  ██▒ ▓▒▓██ ▒ ██▒▒██▒  ██▒
▓██    ▓██░▓██  ▒██░▒██░  ▒ ▓██░ ▒░▒██▒   ▒ ▓██░ ▒░▒██░  ██▒▒██░  ██▒▒██░       ▓██  ▀█ ██▒▒██▒▒ ▓██░ ▒░▓██ ░▄█ ▒▒██░  ██▒
▒██    ▒██ ▓▓█  ░██░▒██░  ░ ▓██▓ ░ ░██░   ░ ▓██▓ ░ ▒██   ██░▒██   ██░▒██░       ▓██▒  ▐▌██▒░██░░ ▓██▓ ░ ▒██▀▀█▄  ▒██   ██░
▒██▒   ░██▒▒▒█████▓ ░██████▒▒██▒ ░ ░██░     ▒██▒ ░ ░ ████▓▒░░ ████▓▒░░██████▒   ▒██░   ▓██░░██░  ▒██▒ ░ ░██▓ ▒██▒░ ████▓▒░
░ ▒░   ░  ░░▒▓▒ ▒ ▒ ░ ▒░▓  ░▒ ░░   ░▓       ▒ ░░   ░ ▒░▒░▒░ ░ ▒░▒░▒░ ░ ▒░▓  ░   ░ ▒░   ▒ ▒ ░▓    ▒ ░░   ░ ▒▓ ░▒▓░░ ▒░▒░▒░ 
░  ░      ░░░▒░ ░ ░ ░ ░ ▒  ░  ░     ▒ ░       ░      ░ ▒ ▒░   ░ ▒ ▒░ ░ ░ ▒  ░   ░ ░░   ░ ▒░ ▒ ░    ░      ░▒ ░ ▒░  ░ ▒ ▒░ 
░      ░    ░░░ ░ ░   ░ ░   ░       ▒ ░     ░      ░ ░ ░ ▒  ░ ░ ░ ▒    ░ ░         ░   ░ ░  ▒ ░  ░        ░░   ░ ░ ░ ░ ▒  
       ░      ░         ░  ░        ░                  ░ ░      ░ ░      ░  ░            ░  ░              ░         ░ ░  
                                                                                                                          

''')

print("This script has been patched, to purchase the unpatched version, contact me on discord @uutu or on telegram @tahagorme")

def handle_exception(loop, context):
    exception = context.get('exception', context['message'])
    print(f"{Fore.RED}[ERROR] Unhandled exception: {exception}")

loop = asyncio.get_event_loop()
loop.set_exception_handler(handle_exception)

with open('config.json') as f:
    config = json.load(f)

total_joined = 0
failed = 0
invite = config['invite']
invite_code = invite.split('/')[-1] if '.' in invite else invite

print(f"\033[1;35mToken Joiner by @uutu\033[0m")

async def read_tokens():
    with open('tokens.txt', 'r') as f:
        tokens = f.read().splitlines()
    
    for i, token in enumerate(tokens):
        await asyncio.sleep(i * config['joinDelay'])
        await do_everything(token.strip(), tokens)

with open('proxies.txt', 'r') as f:
    proxies = f.read().splitlines()

async def do_everything(token, tokens):
    global total_joined, failed
    
    random_proxy = random.choice(proxies).strip()
    
    headers = {
        "Authorization": token,
        "Content-Type": "application/json",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.61 Safari/537.36"
    }
    
    async with aiohttp.ClientSession(headers=headers) as session:
        if config['useProxies']:
            session._connector._ssl = False
            proxy_auth = aiohttp.BasicAuth(random_proxy.split(':')[2], random_proxy.split(':')[3])
            async with session.post(f'https://discordapp.com/api/v9/invites/{invite_code}', proxy=f"http://{random_proxy.split(':')[0]}:{random_proxy.split(':')[1]}", proxy_auth=proxy_auth) as response:
                if response.status == 200:
                    print(f"\033[92mSuccessfully joined with {token[:20]}...\033[0m")
                    total_joined += 1
                else:
                    print(f"\033[91mFailed to join with {token[:20]}... Status code: {response.status}\033[0m")
                    failed += 1
        else:
            async with session.post(f'https://discordapp.com/api/v9/invites/{invite_code}') as response:
                if response.status == 200:
                    print(f"\033[92mSuccessfully joined with {token[:20]}...\033[0m")
                    total_joined += 1
                else:
                    print(f"\033[91mFailed to join with {token[:20]}... Status code: {response.status}\033[0m")
                    failed += 1
    
    print(f"\033[94mTotal Joined: {total_joined} | Failed: {failed}\033[0m")

loop.run_until_complete(read_tokens())

